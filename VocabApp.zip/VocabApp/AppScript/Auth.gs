function getAccessToken_() {
  const key = PropertiesService.getScriptProperties()
    .getProperty('FIREBASE_SERVICE_ACCOUNT');

  if (!key) {
    throw new Error(
      'FIREBASE_SERVICE_ACCOUNT chưa được cấu hình trong Script Properties'
    );
  }

  const serviceAccount = JSON.parse(key);

  const jwtHeader = Utilities.base64EncodeWebSafe(
    JSON.stringify({ alg: 'RS256', typ: 'JWT' })
  ).replace(/=+$/, '');

  const now = Math.floor(Date.now() / 1000);

  const jwtClaim = Utilities.base64EncodeWebSafe(
    JSON.stringify({
      iss: serviceAccount.client_email,
      scope: 'https://www.googleapis.com/auth/datastore',
      aud: serviceAccount.token_uri,
      exp: now + 3600,
      iat: now
    })
  ).replace(/=+$/, '');

  const signature = Utilities.base64EncodeWebSafe(
    Utilities.computeRsaSha256Signature(
      `${jwtHeader}.${jwtClaim}`,
      serviceAccount.private_key
    )
  ).replace(/=+$/, '');

  const jwt = `${jwtHeader}.${jwtClaim}.${signature}`;

  const response = UrlFetchApp.fetch(serviceAccount.token_uri, {
    method: 'post',
    payload: {
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion: jwt
    }
  });

  const token = JSON.parse(response.getContentText());
  return token.access_token;
}
