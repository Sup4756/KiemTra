function doGet(e) {
return HtmlService.createHtmlOutputFromFile('index')
.setTitle('Vocab App')
.addMetaTag('viewport', 'width=device-width, initial-scale=1')
.setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
function include(filename) {
return HtmlService.createHtmlOutputFromFile(filename).getContent();
}
function myURL() {
return ScriptApp.getService().getUrl();
}
