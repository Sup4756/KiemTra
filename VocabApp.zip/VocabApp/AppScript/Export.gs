function exportTopicToExcel(topic) {
  if (!topic || !topic.words) return null;

  const ss = SpreadsheetApp.create(topic.topic);
  try {
    const sheet = ss.getActiveSheet();
    sheet.appendRow([
      "Word", "Meaning", "Part", "Example", "Level", "UK", "US"
    ]);

    topic.words.forEach(w => {
      sheet.appendRow([
        w.word,
        w.meaning !== null && typeof w.meaning === "object"
          ? JSON.stringify(w.meaning) : w.meaning,
        w.partOfSpeech,
        w.example,
        w.level,
        w.pronunciations.uk,
        w.pronunciations.us
      ]);
    });

    SpreadsheetApp.flush();

    // Lấy XLSX thật, không chỉ đổi đuôi file từ một blob bất kỳ.
    const mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    const url = `https://www.googleapis.com/drive/v3/files/${ss.getId()}/export` +
      `?mimeType=${encodeURIComponent(mimeType)}`;
    const blob = UrlFetchApp.fetch(url, {
      headers: {
        Authorization: `Bearer ${ScriptApp.getOAuthToken()}`
      }
    }).getBlob();

    return Utilities.base64Encode(blob.getBytes());
  } finally {
    DriveApp.getFileById(ss.getId()).setTrashed(true);
  }
}
