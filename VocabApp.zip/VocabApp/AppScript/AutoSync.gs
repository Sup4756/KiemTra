/**
 * Thêm file này vào cùng dự án Apps Script đang chạy Vocab App.
 * Giữ nguyên Import.gs, Data.gs, Auth.gs, Filter.gs, Export.gs và index.html.
 *
 * Cấu hình Script Property:
 * DICTIONARY_SHEET_ID = ID của chính Google Sheet Dictionary bạn đang dùng.
 *
 * Chạy autoSyncDictionary một lần trong editor để kiểm tra/cấp quyền.
 * Sau đó tạo Time-driven trigger gọi autoSyncDictionary mỗi 5 phút.
 * Đồng bộ hai tab đã kiểm thử: Animal và Communication.
 *
 * Chỉ ghi khi nội dung tab thay đổi; không tự xóa document topic cũ.
 * Xóa một từ trong topic vẫn còn từ khác sẽ cập nhật mảng words tương ứng.
 * Xóa hết hoặc đổi tên một topic có thể để lại document cũ trên Firestore,
 * giống cách import thủ công hiện tại. Đây chưa phải đồng bộ xóa đầy đủ.
 *
 * Dùng PROJECT_ID, API_KEY, getAccessToken_(), validateHeaders_(),
 * validateDocumentId_(), setNestedField_(), convertToFirestoreDocFormat()
 * từ bộ code hiện có. Không dùng getUi() hoặc active sheet khi chạy nền.
 */
function autoSyncDictionary() {
  const properties = PropertiesService.getScriptProperties();
  const spreadsheetId = properties.getProperty("DICTIONARY_SHEET_ID");
  if (!spreadsheetId) {
    throw new Error("Hãy cấu hình DICTIONARY_SHEET_ID trong Script Properties.");
  }

  const lock = LockService.getScriptLock();
  if (!lock.tryLock(1000)) {
    console.log("Bỏ qua: một lượt đồng bộ tự động khác đang chạy.");
    return;
  }

  try {
    const spreadsheet = SpreadsheetApp.openById(spreadsheetId);
    const sheetNames = ["Animal", "Communication"];
    let accessToken = null;

    for (const sheetName of sheetNames) {
      const sheet = spreadsheet.getSheetByName(sheetName);
      if (!sheet) throw new Error(`Không tìm thấy tab "${sheetName}".`);
      validateDocumentId_(sheetName, "Tên sheet");

      const data = sheet.getDataRange().getValues();
      if (data.length < 2) {
        console.log(`${sheetName}: chưa có dữ liệu; giữ nguyên Firestore.`);
        continue;
      }

      const hash = Utilities.base64EncodeWebSafe(
        Utilities.computeDigest(
          Utilities.DigestAlgorithm.SHA_256,
          JSON.stringify(data),
          Utilities.Charset.UTF_8
        )
      );
      const hashKey = `VOCAB_AUTO_HASH_${PROJECT_ID}_${spreadsheetId}_${sheet.getSheetId()}`;
      if (properties.getProperty(hashKey) === hash) {
        console.log(`${sheetName}: không thay đổi, bỏ qua ghi Firestore.`);
        continue;
      }

      const headers = data[0].map(header => String(header).trim());
      validateHeaders_(headers);
      const topicMap = Object.create(null);
      let wordCount = 0;

      for (let i = 1; i < data.length; i++) {
        const row = data[i];
        if (row.every(value => value === "" || value == null)) continue;
        if (row.length < headers.length || row.some(value => value == null)) {
          throw new Error(`${sheetName}: dòng ${i + 1} thiếu dữ liệu.`);
        }

        const wordDoc = Object.create(null);
        headers.forEach((header, j) => setNestedField_(wordDoc, header, row[j]));
        if (wordDoc.topic !== null && typeof wordDoc.topic === "object") {
          throw new Error(`${sheetName}: topic ở dòng ${i + 1} phải là giá trị đơn.`);
        }
        const topicKey = wordDoc.topic === undefined
          ? "Unknown"
          : String(wordDoc.topic).trim() || "Unknown";
        validateDocumentId_(topicKey, `Topic ở dòng ${i + 1}`);
        if (!topicMap[topicKey]) topicMap[topicKey] = [];
        topicMap[topicKey].push(wordDoc);
        wordCount++;
      }

      const topicKeys = Object.keys(topicMap);
      if (!accessToken && topicKeys.length) accessToken = getAccessToken_();

      for (const topicKey of topicKeys) {
        const path = `flashcard/${encodeURIComponent(sheetName)}/words/${encodeURIComponent(topicKey)}`;
        const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}` +
          `/databases/(default)/documents/${path}?key=${encodeURIComponent(API_KEY)}` +
          "&updateMask.fieldPaths=topic&updateMask.fieldPaths=words";
        const response = UrlFetchApp.fetch(url, {
          method: "patch",
          headers: { Authorization: `Bearer ${accessToken}` },
          contentType: "application/json",
          payload: JSON.stringify({
            fields: convertToFirestoreDocFormat({ topic: topicKey, words: topicMap[topicKey] })
          }),
          muteHttpExceptions: true
        });
        const status = response.getResponseCode();
        if (status < 200 || status >= 300) {
          throw new Error(`${sheetName}/${topicKey}: HTTP ${status}\n${response.getContentText()}`);
        }
      }

      // Chỉ đánh dấu đã đồng bộ sau khi tất cả topic của tab ghi thành công.
      properties.setProperty(hashKey, hash);
      console.log(`${sheetName}: đã đồng bộ ${topicKeys.length} topic, ${wordCount} dòng từ vựng.`);
    }
  } finally {
    lock.releaseLock();
  }
}
