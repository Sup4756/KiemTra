/** Notes:
 * Import sheet đang mở trong Google Sheets lên Cloud Firestore.
 *
 * Cách dùng:
 * 1. Google Sheets -> Extensions (Tiện ích mở rộng) -> Apps Script.
 * 2. Thay nội dung Code.gs bằng toàn bộ nội dung file này và lưu.
 * 3. Tải lại Google Sheets -> Firestore -> Import sheet lên Firestore.
 * 4. Cấp quyền cho Apps Script khi Google yêu cầu.
 *
 * Dòng 1 là tiêu đề cột. Ví dụ: topic, word, meaning.vi, meaning.en.
 * Dấu chấm trong tiêu đề tạo object lồng nhau.
 * Dòng trống hoàn toàn được bỏ qua; ô trống trong dòng có dữ liệu được giữ lại.
 * Không có topic hoặc topic trống thì gom vào "Unknown".
 *
 * Cấu trúc đích:
 * flashcard/{tên sheet}/words/{topic phụ}
 * Mỗi document có: { topic: "...", words: [ ...các dòng cùng topic... ] }.
 *
 * Giữ cách lưu dữ liệu của bản gốc: mọi giá trị đơn được đổi thành string.
 * Import lại sẽ THAY THẾ mảng words của từng topic có trong sheet.
 * Các topic không có trong lần import này không bị xóa.
 * Các field khác ngoài topic và words trong document được giữ nguyên.
 * Mỗi document Firestore có giới hạn 1 MiB; chia nhỏ topic nếu quá lớn.
 *
 * Xác thực: getAccessToken_() trong Auth.gs cấp token cho service account.
 * Service account cần quyền IAM đọc/ghi Firestore trong project đích.
 */

const PROJECT_ID = "vocab-demo";
const API_KEY = "AIzaSyCG3qPKVwmfIUWU8jeFGgducr9UTB6yFSA";

function importSheetToFirestore() {
  const ui = SpreadsheetApp.getUi();
  let importedTopics = 0;
  let totalTopics = 0;
  let currentTopic = "";

  try {
    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    if (!spreadsheet) {
      throw new Error("Hãy chạy script từ Google Sheets có liên kết với script này.");
    }

    const sheet = spreadsheet.getActiveSheet();
    const sheetName = sheet.getName();
    validateDocumentId_(sheetName, "Tên sheet");

    const data = sheet.getDataRange().getValues();
    if (data.length < 2) {
      ui.alert("Sheet chưa có dữ liệu để import. Dòng đầu cần là tiêu đề cột.");
      return;
    }

    const headers = data[0].map(function (header) {
      return String(header).trim();
    });
    validateHeaders_(headers);

    const topicMap = Object.create(null);
    let skippedRows = 0;
    let wordCount = 0;

    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      if (row.every(function (value) { return value === "" || value == null; })) {
        skippedRows++;
        continue;
      }

      if (row.length < headers.length || row.some(function (value) {
        return value === undefined || value === null;
      })) {
        Logger.log(`Bỏ qua dòng ${i + 1} do thiếu dữ liệu.`);
        skippedRows++;
        continue;
      }

      const wordDoc = Object.create(null);
      for (let j = 0; j < headers.length; j++) {
        setNestedField_(wordDoc, headers[j], row[j]);
      }

      if (wordDoc.topic !== null && typeof wordDoc.topic === "object") {
        throw new Error(`Dòng ${i + 1}: topic phải là giá trị đơn, không phải object.`);
      }

      const topicKey = wordDoc.topic === undefined
        ? "Unknown"
        : String(wordDoc.topic).trim() || "Unknown";
      validateDocumentId_(topicKey, `Topic tại dòng ${i + 1}`);

      if (!topicMap[topicKey]) {
        topicMap[topicKey] = [];
      }
      topicMap[topicKey].push(wordDoc);
      wordCount++;
    }

    const topicKeys = Object.keys(topicMap);
    totalTopics = topicKeys.length;
    if (totalTopics === 0) {
      ui.alert("Không có dòng dữ liệu hợp lệ để import.");
      return;
    }

    const collectionPath = `flashcard/${encodeURIComponent(sheetName)}/words`;

    const accessToken = getAccessToken_();

    for (let i = 0; i < topicKeys.length; i++) {
      const topicKey = topicKeys[i];
      currentTopic = topicKey;

      const doc = {
        topic: topicKey,
        words: topicMap[topicKey]
      };
      const payload = {
        fields: convertToFirestoreDocFormat(doc)
      };

      const url =
        `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}` +
        `/databases/(default)/documents/${collectionPath}/${encodeURIComponent(topicKey)}` +
        `?key=${encodeURIComponent(API_KEY)}` +
        "&updateMask.fieldPaths=topic&updateMask.fieldPaths=words";

      const response = UrlFetchApp.fetch(url, {
        method: "patch",
        headers: { Authorization: `Bearer ${accessToken}` },
        contentType: "application/json",
        payload: JSON.stringify(payload),
        muteHttpExceptions: true
      });
      const statusCode = response.getResponseCode();

      if (statusCode < 200 || statusCode >= 300) {
        const errorText = response.getContentText();
        Logger.log(`Lỗi khi import topic "${topicKey}" -> HTTP ${statusCode}`);
        Logger.log(`Nội dung lỗi: ${errorText}`);
        let hint = "";
        if (statusCode === 401 || statusCode === 403) {
          hint = "\nAPI key không tự cấp quyền ghi. Kiểm tra xác thực và quyền Firestore.";
        }
        throw new Error(`HTTP ${statusCode}${hint}\nChi tiết lỗi:\n${errorText}`);
      }

      importedTopics++;
      Logger.log(`Đã import topic "${topicKey}" (${topicMap[topicKey].length} từ) -> ${statusCode}`);
    }

    ui.alert(
      `Đã import thành công sheet "${sheetName}".\n` +
      `Số topic: ${importedTopics}\n` +
      `Số dòng từ vựng: ${wordCount}\n` +
      `Số dòng bỏ qua: ${skippedRows}`
    );
  } catch (error) {
    const message = error && error.message ? error.message : String(error);
    Logger.log(`Import dừng: ${message}`);
    ui.alert(
      "Import đã dừng.\n" +
      (currentTopic ? `Topic đang xử lý: "${currentTopic}"\n` : "") +
      `Đã ghi thành công ${importedTopics}/${totalTopics} topic.\n` +
      (importedTopics > 0 ? "Các topic đã ghi trước lỗi vẫn được giữ trên Firestore.\n" : "") +
      `\n${message}`
    );
  }
}

/** Kiểm tra tiêu đề trước khi gửi bất kỳ dữ liệu nào. */
function validateHeaders_(headers) {
  const seen = [];
  headers.forEach(function (header, index) {
    const parts = header.split(".");
    if (parts.some(function (part) { return !part.trim() || /^__.*__$/.test(part); })) {
      throw new Error(`Tiêu đề cột ${index + 1} rỗng hoặc không hợp lệ: "${header}".`);
    }

    seen.forEach(function (existing) {
      if (existing === header || existing.indexOf(header + ".") === 0 ||
          header.indexOf(existing + ".") === 0) {
        throw new Error(`Tiêu đề bị trùng hoặc xung đột: "${existing}" và "${header}".`);
      }
    });
    seen.push(header);
  });
}

/** Ví dụ meaning.vi -> { meaning: { vi: value } }. */
function setNestedField_(target, fieldPath, value) {
  const parts = fieldPath.split(".");
  let current = target;
  for (let i = 0; i < parts.length - 1; i++) {
    if (!Object.prototype.hasOwnProperty.call(current, parts[i])) {
      current[parts[i]] = Object.create(null);
    }
    current = current[parts[i]];
  }
  current[parts[parts.length - 1]] = value;
}

/** Tên sheet và topic phụ được dùng làm document ID. */
function validateDocumentId_(value, label) {
  if (!value || value.indexOf("/") !== -1 || value === "." || value === ".." ||
      /^__.*__$/.test(value) || Utilities.newBlob(value).getBytes().length > 1500) {
    throw new Error(
      `${label} không dùng được làm document ID: "${value}". ` +
      "ID không được rỗng, chứa /, là . hoặc .., có dạng __...__, hoặc vượt 1.500 byte."
    );
  }
}

/** Chuyển object thành map fields đúng định dạng REST API của Firestore. */
function convertToFirestoreDocFormat(data) {
  const result = Object.create(null);
  Object.keys(data).forEach(function (key) {
    result[key] = toFirestoreValue_(data[key]);
  });
  return result;
}

function toFirestoreValue_(value) {
  if (Array.isArray(value)) {
    return {
      arrayValue: {
        values: value.map(function (item) {
          return toFirestoreValue_(item);
        })
      }
    };
  }

  if (value !== null && typeof value === "object" && !(value instanceof Date)) {
    return {
      mapValue: {
        fields: convertToFirestoreDocFormat(value)
      }
    };
  }

  return { stringValue: String(value) };
}

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("Firestore")
    .addItem("Import sheet lên Firestore", "importSheetToFirestore")
    .addToUi();
}
