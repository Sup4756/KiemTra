function filterTopics(level, pos) {
  const filtered = fetchAllTopics().map(t => {
    let words = t.words;

    if (level) {
      words = words.filter(w => w.level == level);
    }

    if (pos) {
      words = words.filter(w => w.partOfSpeech == pos);
    }

    return { ...t, words };
  });

  return filtered.filter(t => t.words.length > 0);
}
