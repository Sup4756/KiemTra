/**
 * Đọc dữ liệu theo cấu trúc flashcard/{tên sheet}/words/{topic phụ}.
 * Thêm file này vào dự án Apps Script chứa HTML Vocab App.
 * Tên cấu hình có tiền tố VOCAB_ để không trùng PROJECT_ID trong file import.
 *
 * File chỉ đọc dữ liệu, không ghi/xóa Firestore.
 * Request Firestore dùng token service account từ Auth.gs.
 * Firebase Auth trên HTML và token service account là hai cơ chế khác nhau.
 *
 * vocabDataCache_ chỉ tái sử dụng trong cùng một lần thực thi Apps Script;
 * không phải cache dùng chung giữa các lần gọi google.script.run.
 */
const VOCAB_PROJECT_ID = "vocab-demo";
const VOCAB_API_KEY = "AIzaSyCG3qPKVwmfIUWU8jeFGgducr9UTB6yFSA";


const VOCAB_BASE_URL =
  `https://firestore.googleapis.com/v1/projects/${VOCAB_PROJECT_ID}/databases/(default)/documents`;

let vocabDataCache_ = null;

function fetchAllTopics(forceRefresh) {
  if (vocabDataCache_ !== null && !forceRefresh) return vocabDataCache_;

  const accessToken = getAccessToken_();
  const allTopics = [];
  // Import vào subcollection không tự tạo document cha có fields.
  // showMissing=true giúp liệt kê cả các document cha chỉ có subcollection.
  const sheetDocuments = vocabListDocuments_("flashcard", true, accessToken);

  sheetDocuments.forEach(function (sheetDoc) {
    const sheetName = sheetDoc.name.split("/").pop();
    const path = `flashcard/${encodeURIComponent(sheetName)}/words`;
    const documents = vocabListDocuments_(path, false, accessToken);

    documents.forEach(function (doc) {
      const fields = vocabDecodeFields_(doc.fields || {});
      const topic = String(fields.topic ?? "Unknown");
      const wordsArr = fields.words ?? [];
      if (!Array.isArray(wordsArr)) {
        throw new Error(`Document ${doc.name}: field words phải là một mảng.`);
      }

      const words = wordsArr.map(function (x, index) {
        if (!x || typeof x !== "object" || Array.isArray(x)) {
          throw new Error(`Document ${doc.name}: phần tử words thứ ${index + 1} phải là map.`);
        }
        return {
          word: x.word ?? "",
          meaning: x.meaning ?? "",
          partOfSpeech: x.partOfSpeech ?? "",
          example: x.example ?? x.Example ?? "",
          level: x.level ?? "",
          pronunciations: {
            uk: x.pronunciations?.uk ?? "",
            us: x.pronunciations?.us ?? ""
          },
          topic: x.topic ?? topic
        };
      });

      // Dùng đường dẫn document làm ID để topic trùng tên không bị lọc nhầm.
      allTopics.push({ id: doc.name, topic: topic, words: words });
    });
  });

  // Chỉ cập nhật cache khi đã đọc thành công tất cả các trang.
  vocabDataCache_ = allTopics;
  return vocabDataCache_;
}

/** Tên hàm tải dữ liệu mà HTML Vocab App đã sửa đang gọi. */
function getTopics() {
  return fetchAllTopics(true);
}

/** Đọc đủ mọi trang, không giới hạn tổng số document ở 100. */
function vocabListDocuments_(collectionPath, showMissing, accessToken) {
  const documents = [];
  let pageToken = "";

  do {
    let url = `${VOCAB_BASE_URL}/${collectionPath}?pageSize=100` +
      `&key=${encodeURIComponent(VOCAB_API_KEY)}`;
    if (showMissing) url += "&showMissing=true";
    if (pageToken) url += `&pageToken=${encodeURIComponent(pageToken)}`;

    const response = UrlFetchApp.fetch(url, {
      method: "get",
      headers: { Authorization: `Bearer ${accessToken}` },
      muteHttpExceptions: true
    });
    const statusCode = response.getResponseCode();
    const responseText = response.getContentText();
    if (statusCode < 200 || statusCode >= 300) {
      throw new Error(`Không đọc được ${collectionPath}: HTTP ${statusCode}\n${responseText}`);
    }

    let data;
    try {
      data = JSON.parse(responseText);
    } catch (error) {
      throw new Error(`Phản hồi của ${collectionPath} không phải JSON hợp lệ.`);
    }
    if (!data || typeof data !== "object" || Array.isArray(data)) {
      throw new Error(`Phản hồi của ${collectionPath} không đúng cấu trúc Firestore.`);
    }
    if (data.documents !== undefined && !Array.isArray(data.documents)) {
      throw new Error(`Phản hồi của ${collectionPath}: documents phải là mảng.`);
    }
    (data.documents || []).forEach(function (doc) { documents.push(doc); });
    pageToken = data.nextPageToken || "";
  } while (pageToken);

  return documents;
}

function vocabDecodeFields_(fields) {
  const result = Object.create(null);
  Object.keys(fields).forEach(function (key) {
    result[key] = vocabDecodeValue_(fields[key]);
  });
  return result;
}

/** Bỏ lớp stringValue/mapValue/arrayValue của Firestore REST. */
function vocabDecodeValue_(value) {
  if (!value || typeof value !== "object") {
    throw new Error("Giá trị Firestore không hợp lệ.");
  }
  if ("stringValue" in value) return value.stringValue;
  // Giữ integerValue ở dạng chuỗi để không mất độ chính xác với số nguyên lớn.
  if ("integerValue" in value) return String(value.integerValue);
  if ("doubleValue" in value) return value.doubleValue;
  if ("booleanValue" in value) return value.booleanValue;
  if ("nullValue" in value) return null;
  if ("timestampValue" in value) return value.timestampValue;
  if ("mapValue" in value) return vocabDecodeFields_(value.mapValue.fields || {});
  if ("arrayValue" in value) return (value.arrayValue.values || []).map(vocabDecodeValue_);
  throw new Error("Gặp kiểu dữ liệu Firestore chưa được hỗ trợ trong dữ liệu từ vựng.");
}
