# Vocab App

Ứng dụng quản lý và xem từ vựng theo chủ đề, kết hợp AppSheet, Google Sheets, Google Apps Script, Firebase và Google Data Studio (trước đây là Looker Studio).

## 1. Chức năng hiện có

- Quản lý từ vựng bằng AppSheet.
- Lưu dữ liệu nguồn trong Google Sheets.
- Chạy Apps Script để nhập dữ liệu theo chủ đề lên Cloud Firestore.
- Đăng nhập giao diện web bằng Firebase Authentication theo các phương thức đã bật trong project.
- Xem chủ đề, danh sách từ vựng; lọc theo trình độ và từ loại.
- Xuất dữ liệu từ vựng ra file Excel `.xlsx`.
- Thống kê dữ liệu từ vựng bằng Data Studio, sử dụng bảng DashboardData trong Sheets.

## 2. Luồng dữ liệu

**Phục vụ web:** AppSheet → Google Sheets → chạy Apps Script import thủ công → Cloud Firestore → Apps Script Web App.

**Thống kê:** Animal và Communication → DashboardData trong Google Sheets → Data Studio.

Chỉnh sửa AppSheet không tự chạy import lên Firestore. Muốn web thấy nội dung mới, cần đồng bộ AppSheet về Sheets, chạy import cho bảng đã sửa và làm mới dữ liệu web. Dashboard đọc Sheets riêng, theo thời điểm làm mới của nguồn dữ liệu.

## 3. Thành phần của gói bàn giao

| Thành phần | Nội dung |
| --- | --- |
| `AppsScript/` | Các file `.gs`, `.html` đang sử dụng và `appsscript.json`. Nếu có nhiều dự án Apps Script, đặt mỗi dự án trong một thư mục riêng. |
| `Firebase/` | Rules hiện hành, mô tả cấu trúc dữ liệu và ghi chú cấu hình Authentication. |
| `Data/` | Dữ liệu nguồn, công thức tổng hợp và bản sao bảng tính. |
| `AppSheet/` | Link ứng dụng/editor. |
| `DataStudio/` | Link dashboard, bản PDF. |

## 4. Thông tin project

| Thông tin | Giá trị cần điền |
| --- | --- |
| Firebase / Google Cloud Project ID | vocab-demo |
| Google Sheets nguồn | https://docs.google.com/spreadsheets/d/1imfnK-GrAJ5aaO2aEjPQf9fes-T4W1adlIwVValk_Mc/edit?gid=0#gid=0 |
| Apps Script dùng để import | https://script.google.com/home/projects/1Bo8aAxy665NWM8aurpKAdRArbU8gb02V3Qn63rD3huSMCSFP0NuZ84Hn/edit |
| Apps Script cung cấp Web App | Cùng dự án |
| Web App URL | https://script.google.com/macros/s/AKfycbzUwjpYwEk8HxqkfuCU0STWKZMpPtNYXbZNKIvkZOLpsB2-B2n-ppjexZhGabUEQXukGQ/exec |
| Phiên bản triển khai | Phiên bản 8 - refresh 2 |
| Execute as / Who has access | Tôi (người dùng) |
| AppSheet | https://www.appsheet.com/template/AppDef?appName=VocabAdmin-343041352&appId=d55c5108-84cb-4b1e-a10c-a1eff2285b79&quickStart=False#Data.Columns.Animal |
| Data Studio | https://datastudio.google.com/u/0/reporting/e0941398-45c9-462c-a695-5b42cb524110/page/wFVCG |
| Service account được sử dụng | test123@gmail.com - 12301230 |
| Phương thức Firebase Authentication đang bật | Email/Password |

## 5. Dữ liệu nguồn và Firestore

Ví dụ bảng dữ liệu nguồn: `Animal` và `Communication`.

Các cột dữ liệu từ vựng gồm:

`word`, `partOfSpeech`, `meaning`, `example` hoặc `Example`, `pronunciations.uk`, `pronunciations.us`, `level`, `topic`.



Cấu trúc Firestore:

```text
flashcard/{sheetName}/words/{topicKey}
```

- `sheetName`: tên bảng nguồn.
- `topicKey`: ID document chủ đề do mã import tạo.
- Document chủ đề chứa trường `topic` và mảng `words`.
- Mỗi phần tử trong `words` chứa nội dung từ vựng và thông tin phát âm UK/US.

Nguồn bộ từ vựng: Sheet Dictionary.

## 6. Cấu hình để chạy lại

### 6.1. Google Sheets và Apps Script

1. Tạo bản sao Google Sheets, giữ dữ liệu Animal, Communication và công thức DashboardData. Nếu chỉ có Excel, đưa dữ liệu lên Sheets và kiểm tra lại công thức.
2. Khôi phục các file Apps Script vào đúng dự án tương ứng. Chức năng menu/import cần nằm trong dự án gắn với bảng tính nếu mã sử dụng bảng tính đang mở.
3. Đối chiếu các ID bảng tính, tên tab, Project ID và cấu hình Firebase trong toàn bộ file mã nguồn; cập nhật theo tài nguyên mới.
4. Giữ `appsscript.json` và các quyền OAuth cần cho phiên bản mã đang dùng. Chấp thuận quyền khi chạy chức năng cần thiết lần đầu.

### 6.2. Firebase và thông tin xác thực phía server

1. Dùng project Firebase hiện tại có quyền truy cập, hoặc tạo project mới và Cloud Firestore tương ứng.
2. Bật các phương thức đăng nhập được ghi ở mục 4. Tạo tài khoản thử nghiệm nếu dùng Email/Password.
3. Cập nhật Firebase web config trong HTML, Project ID và API key trong các file server có sử dụng. Tất cả phải trỏ tới project dự định dùng.
4. Dùng service account được cấp quyền phù hợp với các thao tác đọc/ghi của ứng dụng. Nếu dựng lại bằng service account mới, quản trị viên phải cấu hình quyền cho tài khoản mới.
5. Trong Apps Script → Project Settings → Script Properties, tạo thuộc tính `FIREBASE_SERVICE_ACCOUNT`; giá trị là nội dung JSON thông tin xác thực của service account được cung cấp qua kênh riêng.
6. Nếu import và web là hai dự án Apps Script riêng, cấu hình Script Property ở cả dự án thực sự gọi `getAccessToken_()`.
7. Lưu Rules hiện hành để đối chiếu. Request Firestore dùng OAuth token của service account được phân quyền qua IAM; không dùng kết quả bài lab Rules với Firebase ID token để khẳng định quyền của luồng service account.

### 6.3. Nhập dữ liệu lần đầu

1. Mở lại Google Sheets để menu do `onOpen()` tạo xuất hiện.
2. Chọn tab Animal, chạy mục import của project (hàm `importSheetToFirestore()` trong phiên bản đã trao đổi).
3. Đợi lần chạy hoàn tất; kiểm tra dữ liệu tương ứng trong Firestore.
4. Làm tương tự với tab Communication.
5. Nếu mã hoặc tên hàm đã đổi, đối chiếu menu và source thực tế trước khi thực hiện.

### 6.4. Triển khai Web App

1. Trong dự án cung cấp giao diện web, chọn Deploy → New deployment → Web app khi tạo bản triển khai mới.
2. Thiết lập Execute as và Who has access theo phạm vi sử dụng dự định; ghi lại giá trị thực tế ở mục 4.
3. Hoàn thành triển khai và mở Web App URL kết thúc bằng `/exec`.
4. Đăng nhập, tải chủ đề, thử lọc và xuất Excel.
5. Khi cập nhật mã cho bản đang sử dụng, chọn Deploy → Manage deployments → chọn bản triển khai → Edit → New version → Deploy.

URL `/dev` dành cho kiểm thử của người có quyền chỉnh sửa script; URL `/exec` dùng cho bản triển khai.

### 6.5. AppSheet và Data Studio

1. Dùng bản AppSheet được chia sẻ hoặc tạo bản sao, rồi nối các bảng với đúng Google Sheets nguồn. Kiểm tra lại khóa, kiểu cột, Ref, Slice và View theo cấu hình bàn giao.
2. Tạo bản sao dashboard có quyền chỉnh sửa hoặc dựng lại từ cấu hình được lưu; nối nguồn với tab DashboardData của bảng tính mới.
3. Kiểm tra các trường dữ liệu, calculated field và bộ lọc. Bản PDF dashboard chỉ để tham khảo, không phải bản cấu hình có thể chỉnh sửa.

## 7. Cập nhật dữ liệu hằng ngày

1. Thêm hoặc sửa từ vựng bằng AppSheet.
2. Save/Sync và xác nhận thay đổi đã về đúng tab Google Sheets.
3. Chọn tab đã sửa; chạy import thủ công lên Firestore.
4. Trên Vocab App, chọn làm mới dữ liệu và mở lại chủ đề cần kiểm tra.
5. Trên Data Studio, làm mới dữ liệu khi cần và kiểm tra DashboardData.

Không mặc định rằng xóa một hàng hoặc đổi tên topic trong Sheets sẽ tự dọn mọi document Firestore cũ. Đối chiếu hành vi của mã import hiện hành và kiểm tra document còn dư khi thực hiện các thay đổi này.

## 8. Kiểm tra sau khi khôi phục

| Kiểm tra | Kết quả mong đợi |
| --- | --- |
| Sửa dữ liệu trong AppSheet | Nội dung thay đổi xuất hiện ở đúng bảng Sheets sau đồng bộ. |
| Import thủ công | Lần thực thi thành công; dữ liệu topic trong Firestore khớp nguồn. |
| Đăng nhập và tải chủ đề | Web hiển thị danh sách chủ đề/từ vựng. |
| Lọc trình độ và từ loại | Các dòng hiển thị đáp ứng điều kiện lọc. |
| Xuất Excel | Mở được file `.xlsx`; dữ liệu khớp danh sách đã xuất. |
| Dashboard | Đọc đúng DashboardData; chỉ số và bộ lọc hoạt động với nguồn đã chọn. |

## 9. Giới hạn phiên bản demo

- Chưa triển khai webhook tự động hoặc cập nhật web theo thời gian thực.
- Chưa có quiz, mục yêu thích, lưu tiến độ học hoặc thống kê kết quả học cá nhân.
- Đăng nhập giao diện bằng Firebase Authentication chưa đồng nghĩa mọi hàm backend đã kiểm tra người gọi. Phiên bản demo được mô tả ở đây chưa hoàn thiện kiểm tra Firebase ID token tại backend.
- Backend truy cập Firestore bằng service account.
- Chưa có kết quả kiểm thử tải lớn hoặc nhiều người dùng đồng thời.

## 10. Tài liệu chính thức

- [Apps Script — Script Projects](https://developers.google.com/apps-script/guides/projects)
- [Apps Script — Web Apps](https://developers.google.com/apps-script/guides/web)
- [Google Cloud IAM — View and manage project access](https://docs.cloud.google.com/iam/docs/granting-changing-revoking-access)
- [Firestore — REST API, authentication and authorization](https://firebase.google.com/docs/firestore/use-rest-api)
- [Firebase — API keys](https://firebase.google.com/docs/projects/api-keys)
